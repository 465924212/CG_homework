#include <glad/glad.h> 
#include <GLFW/glfw3.h>
#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include <iostream>
#include <vector>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// to enable resizing the window
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
// to process the input in the window
void processInput(GLFWwindow *window);

// to draw a cube & a plane
unsigned int drawCube();
unsigned int drawPlane();
unsigned int drawQuad();

// to initialize shaders
int initShadowShader();
int initDepthShader();
int initDebugShader();


// settings
const unsigned int WINDOW_WIDTH = 800;
const unsigned int WINDOW_HEIGHT = 600;

int main()
{
	// initialize a window
	glfwInit();
	// init the window with OpenGL 3.3 and with core mode
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// create a window with a size of w800 * h600 and a name
	GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, "Homework 7", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	// make the window a context
	glfwMakeContextCurrent(window);

	// initialize GLAD to use OpenGL functions before using any of them
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

	// initialize ImGUI
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO(); (void)io;
	ImGui::StyleColorsDark();
	ImGui_ImplGlfw_InitForOpenGL(window, true);
	ImGui_ImplOpenGL3_Init("#version 130");

	// init shader program
	int ShadowShader = initShadowShader();
	int DepthShader = initDepthShader();
	int debugShader = initDebugShader();

	// open depth test
	glEnable(GL_DEPTH_TEST);

	// to choose a task & get the parameters
	int task = 0;
	glm::vec3 lightPos = glm::vec3(-2.0f, 4.0f, -1.0f);
	glm::vec3 viewPos = glm::vec3(3.0f, 3.0f, 3.0f);
	glm::vec3 planeColor = glm::vec3(1.0f, 0.0f, 0.0f);
	glm::vec3 cubeColor = glm::vec3(0.0f, 1.0f, 0.0f);
	bool bonus = false;

	unsigned int cubeVAO = drawCube();
	unsigned int planeVAO = drawPlane();
	unsigned int quadVAO = drawQuad();
	
	// generate depth map
	unsigned int SHADOW_WIDTH = 1024, SHADOW_HEIGHT = 1024;
	unsigned int depthMapFBO;
	glGenFramebuffers(1, &depthMapFBO);
	unsigned int depthMap;
	glGenTextures(1, &depthMap);
	glBindTexture(GL_TEXTURE_2D, depthMap);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, SHADOW_WIDTH, SHADOW_HEIGHT, 0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	//make it the depth buffer
	glBindFramebuffer(GL_FRAMEBUFFER, depthMapFBO);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, depthMap, 0);
	glDrawBuffer(GL_NONE);
	glReadBuffer(GL_NONE);
	glBindFramebuffer(GL_FRAMEBUFFER, 0);

	glUseProgram(ShadowShader);
	glUniform1i(glGetUniformLocation(ShadowShader, "shadowMap"), 0);


	// render loop
	while (!glfwWindowShouldClose(window))
	{
		
		// input
		processInput(window);
		// poll event
		glfwPollEvents();

		// draw a ImGUI frame
		ImGui_ImplOpenGL3_NewFrame();
		ImGui_ImplGlfw_NewFrame();
		ImGui::NewFrame();

		ImGui::Begin("Choose Task");
		ImGui::DragFloat3("Light Position", &(lightPos.x), 0.05f);
		ImGui::DragFloat3("View Position", &(viewPos.x), 0.05f);
		ImGui::ColorEdit3("Cube Color", (float*)&cubeColor);
		ImGui::ColorEdit3("Light Color", (float*)&planeColor);
		ImGui::Checkbox("bonus: perspective light", &bonus);

		ImGui::End();

		// render
		glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		//set light
		glm::mat4 lightProjection, lightView, lightSpaceMatrix;
		float near_plane = 1.0f, far_plane = 7.5f;
		lightProjection = bonus ? glm::perspective(45.0f, 1.0f, 0.01f, 100.0f):
			glm::ortho(-10.0f, 10.0f, -10.0f, 10.0f, near_plane, far_plane);
		lightView = glm::lookAt(lightPos, glm::vec3(0.0f), glm::vec3(0.0, 1.0, 0.0));
		lightSpaceMatrix = lightProjection * lightView;

		// render from light's perpective
		glUseProgram(DepthShader);
		glUniformMatrix4fv(glGetUniformLocation(DepthShader, "lightSpaceMatrix"), 1, GL_FALSE, glm::value_ptr(lightSpaceMatrix));
		glViewport(0, 0, SHADOW_WIDTH, SHADOW_HEIGHT);
		glBindFramebuffer(GL_FRAMEBUFFER, depthMapFBO);
		glClear(GL_DEPTH_BUFFER_BIT);
		
		//draw the plane
		glm::mat4 model = glm::mat4(1.0f);
		glUniformMatrix4fv(glGetUniformLocation(DepthShader, "model"), 1, GL_FALSE, glm::value_ptr(model));
		glBindVertexArray(planeVAO);
		glDrawArrays(GL_TRIANGLES, 0, 6);
		glBindVertexArray(0);
		
		//draw the cube
		model = glm::scale(model, glm::vec3(0.3f));
		glUniformMatrix4fv(glGetUniformLocation(DepthShader, "model"), 1, GL_FALSE, glm::value_ptr(model));
		glBindVertexArray(cubeVAO);
		glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);
		
		glBindFramebuffer(GL_FRAMEBUFFER, 0);

		glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
		//render as normal
		glUseProgram(ShadowShader);
		
		//draw the plane and cubes
		glm::mat4 projection = glm::perspective(glm::radians(45.f), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);
		glm::mat4 view = glm::lookAt(viewPos, glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
		glUniformMatrix4fv(glGetUniformLocation(ShadowShader, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(glGetUniformLocation(ShadowShader, "view"), 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(glGetUniformLocation(ShadowShader, "lightSpaceMatrix"), 1, GL_FALSE, glm::value_ptr(lightSpaceMatrix));

		glUniform3f(glGetUniformLocation(ShadowShader, "lightPos"), lightPos.x,  lightPos.y, lightPos.z);
		glUniform3f(glGetUniformLocation(ShadowShader, "viewPos"), viewPos.x, viewPos.y, viewPos.z);
		
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, depthMap);
		
		glUniformMatrix4fv(glGetUniformLocation(ShadowShader, "model"), 1, GL_FALSE, glm::value_ptr(model));
		glUniform3f(glGetUniformLocation(ShadowShader, "objectColor"), planeColor.x, planeColor.y, planeColor.z);
		glBindVertexArray(planeVAO);
		glDrawArrays(GL_TRIANGLES, 0, 6);
		glBindVertexArray(0);
		
		glUniformMatrix4fv(glGetUniformLocation(ShadowShader, "model"), 1, GL_FALSE, glm::value_ptr(model));
		glUniform3f(glGetUniformLocation(ShadowShader, "objectColor"), cubeColor.x, cubeColor.y, cubeColor.z);
		glBindVertexArray(cubeVAO);
		glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);
		
		/*
		glUseProgram(debugShader);
		glUniform1f(glGetUniformLocation(debugShader, "near_plane"), near_plane);
		glUniform1f(glGetUniformLocation(debugShader, "far_plane"), far_plane);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, depthMap);
		glBindVertexArray(quadVAO);
		glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
		glBindVertexArray(0);
		*/

		ImGui::Render();
		ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

		// swap buffers
		glfwSwapBuffers(window);
	}

	// release resources
	ImGui_ImplOpenGL3_Shutdown();
	ImGui_ImplGlfw_Shutdown();
	ImGui::DestroyContext();
	glfwTerminate();
	return 0;
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// configure viewport with new size
	glViewport(0, 0, width, height);
}

void processInput(GLFWwindow *window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
}

unsigned int drawCube()
{
	// load the cube vertices
	float cubeVertices[] = {
	-2.0f, -2.0f, -2.0f, 0.0f, 1.0f, 0.0f,
	 2.0f, -2.0f, -2.0f, 0.0f, 1.0f, 0.0f,
	 2.0f,  2.0f, -2.0f, 0.0f, 1.0f, 0.0f,
	-2.0f,  2.0f, -2.0f, 0.0f, 1.0f, 0.0f,
	-2.0f, -2.0f,  2.0f, 0.0f, 1.0f, 0.0f,
	 2.0f, -2.0f,  2.0f, 0.0f, 1.0f, 0.0f,
	 2.0f,  2.0f,  2.0f, 0.0f, 1.0f, 0.0f,
	-2.0f,  2.0f,  2.0f, 0.0f, 1.0f, 0.0f
	};

	unsigned int cubeIndices[] = {
	0, 1, 2,
	0, 2, 3,
	0, 1, 5,
	0, 4, 5,
	0, 3, 7,
	0, 4, 7,
	6, 2, 3,
	6, 3, 7,
	6, 1, 2,
	6, 1, 5,
	6, 4, 5,
	6, 4, 7
	};

	// generate buffer & array
	unsigned int cubeVBO, cubeVAO, EBO;
	glGenVertexArrays(1, &cubeVAO);
	glGenBuffers(1, &cubeVBO);
	glGenBuffers(1, &EBO);

	// bind the array, bind buffer and set its data
	glBindVertexArray(cubeVAO);
	glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), cubeVertices, GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(cubeIndices), cubeIndices, GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glBindVertexArray(0);

	return cubeVAO;
}

unsigned int drawPlane()
{
	// load the plane
	float planeVertices[] = {
		25.0f, -0.5f, 25.0f, 0.0f, 1.0f, 0.0f,
		-25.0f, -0.5f, -25.0f, 0.0f, 1.0f, 0.0f,
		-25.0f, -0.5f, 25.0f, 0.0f, 1.0f, 0.0f,

		25.0f, -0.5f, 25.0f, 0.0f, 1.0f, 0.0f,
		25.0f, -0.5f, -25.0f, 0.0f, 1.0f, 0.0f,
		-25.0f, -0.5f, -25.0f, 0.0f, 1.0f, 0.0f
	};
	unsigned int planeVAO, planeVBO;
	glGenVertexArrays(1, &planeVAO);
	glGenBuffers(1, &planeVBO);
	glBindVertexArray(planeVAO);
	glBindBuffer(GL_ARRAY_BUFFER, planeVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), &planeVertices, GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glBindVertexArray(0);
	return planeVAO;
}

unsigned int drawQuad()
{
	float quadVertices[] = {
		// Positions        // Texture Coords
		-1.0f,  1.0f, 0.0f,  0.0f, 1.0f,
		-1.0f, -1.0f, 0.0f,  0.0f, 0.0f,
		 1.0f,  1.0f, 0.0f,  1.0f, 1.0f,
		 1.0f, -1.0f, 0.0f,  1.0f, 0.0f,
	};
	unsigned int quadVAO, quadVBO;
	glGenVertexArrays(1, &quadVAO);
	glGenBuffers(1, &quadVBO);
	glBindVertexArray(quadVAO);
	glBindBuffer(GL_ARRAY_BUFFER, quadVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(quadVertices), &quadVertices, GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	return quadVAO;
}


int initShadowShader() {
	// initialize suceess info
	int  success;
	char infoLog[512];

	// vertex shader code
	const char* vertexShaderSource = "#version 330 core\n"
		"layout(location = 0) in vec3 aPos;\n"
		"layout(location = 1) in vec3 aNormal;\n"
		
		"out VS_OUT {"
		"vec3 FragPos;"
		"vec3 Normal;"
		"vec4 FragPosLightSpace;"
		"} vs_out; "
		
		"uniform mat4 model;\n"
		"uniform mat4 view;\n"
		"uniform mat4 projection;\n"
		"uniform mat4 lightSpaceMatrix;\n"

		"void main()"
		"{"
		"	vs_out.FragPos = vec3(model * vec4(aPos, 1.0));"
		"	vs_out.Normal = transpose(inverse(mat3(model))) * aNormal;"
		"	vs_out.FragPosLightSpace = lightSpaceMatrix * vec4(vs_out.FragPos, 1.0); "
		"	gl_Position = projection * view * model * vec4(aPos, 1.0);"
		"}";
	// create & compile vertex shader
	unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);
	// check its success
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
	}


	// fragment shader code
	const char* fragmentShaderSource = "#version 330 core\n"
		"out vec4 FragColor;\n"
		"in VS_OUT{"
		"vec3 FragPos;\n"
		"vec3 Normal;\n"
		"vec4 FragPosLightSpace;\n"
		"} fs_in;\n"

		"uniform sampler2D shadowMap;\n"

		"uniform vec3 lightPos;\n"
		"uniform vec3 viewPos;\n"
		"uniform vec3 objectColor;\n"

		"float ShadowCalculation(vec4 fragPosLightSpace) {"
		"	vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;"
		"	projCoords = projCoords * 0.5 + 0.5;"
		"	float closestDepth = texture(shadowMap, projCoords.xy).r;"
		"	float currentDepth = projCoords.z;"
		"	vec3 normal = normalize(fs_in.Normal);"
		"	vec3 lightDir = normalize(lightPos - fs_in.FragPos);"
		"	float bias = max(0.05 * (1.0 - dot(normal, lightDir)), 0.005);"
		"	float shadow = 0.0;"
		"	vec2 texelSize = 1.0 / textureSize(shadowMap, 0);"
		"	for (int x = -1; x <= 1; ++x) {"
		"		for (int y = -1; y <= 1; ++y) {"
		"			float pcfDepth = texture(shadowMap, projCoords.xy + vec2(x, y) * texelSize).r;"
		"			shadow += currentDepth - bias > pcfDepth ? 1.0 : 0.0;"
		"		}"
		"	}"
		"	shadow /= 9.0;"
		"	if (projCoords.z > 1.0)"
		"		shadow = 0.0;"
		"	return shadow;"
		"}"

		"void main() {"
		"	vec3 color = objectColor;"
		"	vec3 normal = normalize(fs_in.Normal);"
		"	vec3 lightColor = vec3(0.1);"
		"	vec3 ambient = 0.3 * color;"
		"	vec3 lightDir = normalize(lightPos - fs_in.FragPos);"
		"	float diff = max(dot(normal, lightDir), 0.0);"
		"	vec3 diffuse = diff * lightColor;"
		"	vec3 viewDir = normalize(viewPos - fs_in.FragPos);"
		"	vec3 reflectDir = reflect(-lightDir, normal);"
		"	vec3 halfwayDir = normalize(lightDir + viewDir);"
		"	float spec = pow(max(dot(normal, halfwayDir), 0.0), 64.0);"
		"	vec3 specular = spec * lightColor;"
		"	float shadow = ShadowCalculation(fs_in.FragPosLightSpace);"
		"	vec3 lighting = (ambient + (1.0 - shadow) * (diffuse + specular)) * color;"
		"	FragColor = vec4(lighting, 1.0);"
		"}";
	// create & compile fragment shader
	unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);
	// check its success
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
	}

	// create shader program & attach shaders to it
	int shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	// link the shader program
	glLinkProgram(shaderProgram);
	glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
	}
	// delete shaader
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	return shaderProgram;
}

int initDepthShader() {
	// initialize suceess info
	int  success;
	char infoLog[512];

	// vertex shader code
	const char* vertexShaderSource = "#version 330 core\n"
		"layout(location = 0) in vec3 aPos;\n"
		"uniform mat4 model;\n"
		"uniform mat4 lightSpaceMatrix;\n"
		"void main()"
		"{"
		"	gl_Position = lightSpaceMatrix * model * vec4(aPos, 1.0);"
		"}";
	// create & compile vertex shader
	unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);
	// check its success
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
	}


	// fragment shader code
	const char* fragmentShaderSource = "#version 330 core\n"
		"void main()"
		"{}";
	// create & compile fragment shader
	unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);
	// check its success
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
	}

	// create shader program & attach shaders to it
	int shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	// link the shader program
	glLinkProgram(shaderProgram);
	glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
	}
	// delete shaader
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	return shaderProgram;
}

int initDebugShader()
{
	// initialize suceess info
	int  success;
	char infoLog[512];

	// vertex shader code
	const char* vertexShaderSource = "#version 330 core\n"
		"layout(location = 0) in vec3 aPos;"
		"layout (location = 1) in vec2 aTexCoords;"
		"out vec2 TexCoords;"
		"void main()"
		"{"
		"TexCoords = aTexCoords;"
		"	gl_Position = vec4(aPos, 1.0);"
		"}";
	// create & compile vertex shader
	unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);
	// check its success
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
	}


	// fragment shader code
	const char* fragmentShaderSource = "#version 330 core\n"
		"out vec4 FragColor;"
		"in vec2 TexCoords;"
		"uniform sampler2D depthMap;"
		"uniform float near_plane;"
		"uniform float far_plane;"
		"float LinearizeDepth(float depth)"
		"{"
		"	float z = depth * 2.0 - 1.0;"
		"	return (2.0 * near_plane * far_plane) / (far_plane + near_plane - z * (far_plane - near_plane));"
		"}"
		"void main()"
		"{"
		"	float depthValue = texture(depthMap, TexCoords).r;"
		"FragColor = vec4(vec3(depthValue), 1.0);"
		"}";
	// create & compile fragment shader
	unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);
	// check its success
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
	}

	// create shader program & attach shaders to it
	int shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	// link the shader program
	glLinkProgram(shaderProgram);
	glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
	}
	// delete shaader
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	return shaderProgram;
}
