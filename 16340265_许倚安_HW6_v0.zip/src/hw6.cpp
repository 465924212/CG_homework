#include <glad/glad.h> 
#include <GLFW/glfw3.h>
#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include <iostream>
#include <vector>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// to enable resizing the window
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
// to process the input in the window
void processInput(GLFWwindow *window);

// to initialize shaders
int initPhongShader();
int initGouraudShader();
int initLightShader();

// settings
const unsigned int WINDOW_WIDTH = 800;
const unsigned int WINDOW_HEIGHT = 600;

int main()
{
	// initialize a window
	glfwInit();
	// init the window with OpenGL 3.3 and with core mode
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// create a window with a size of w800 * h600 and a name of "A Triangle"
	GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, "Homework 6", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	// make the window a context
	glfwMakeContextCurrent(window);

	// initialize GLAD to use OpenGL functions before using any of them
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// configure viewport size
	// viewport != window
	glViewport(0, 0, 800, 600);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

	// initialize ImGUI
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO(); (void)io;
	ImGui::StyleColorsDark();
	ImGui_ImplGlfw_InitForOpenGL(window, true);
	ImGui_ImplOpenGL3_Init("#version 130");

	// init shader program
	int shader1 = initPhongShader();
	int shader2 = initGouraudShader();
	int LightShader = initLightShader();

	// open depth test
	glEnable(GL_DEPTH_TEST);

	// to choose a task & get the parameters
	int task = 0;
	float ambient = 0.5f, diffuse = 0.5f, specular = 0.5f, shiny = 20.0f;
	glm::vec3 lightPos = glm::vec3(2.0f, 2.0f, 2.0f);
	glm::vec3 viewPos = glm::vec3(5.0f, 8.0f, 3.0f);
	bool bonus = false;

	// load the vertices
	float vertices[] = {
	-2.0f, -2.0f, -2.0f, 0.5f, 0.5f, 0.5f,
	 2.0f, -2.0f, -2.0f, 0.5f, 0.5f, 0.5f,
	 2.0f,  2.0f, -2.0f, 0.5f, 0.5f, 0.5f,
	-2.0f,  2.0f, -2.0f, 0.5f, 0.5f, 0.5f,
	-2.0f, -2.0f,  2.0f, 0.5f, 0.5f, 0.5f,
	 2.0f, -2.0f,  2.0f, 0.5f, 0.5f, 0.5f,
	 2.0f,  2.0f,  2.0f, 0.5f, 0.5f, 0.5f,
	-2.0f,  2.0f,  2.0f, 0.5f, 0.5f, 0.5f
	};

	unsigned int indices[] = {
	0, 1, 2,
	0, 2, 3,
	0, 1, 5,
	0, 4, 5,
	0, 3, 7,
	0, 4, 7,
	6, 2, 3,
	6, 3, 7,
	6, 1, 2,
	6, 1, 5,
	6, 4, 5,
	6, 4, 7
	};

	// generate buffer & array
	unsigned int VBO, cubeVAO, EBO;
	glGenVertexArrays(1, &cubeVAO);
	glGenBuffers(1, &VBO);
	glGenBuffers(1, &EBO);

	// bind the array, bind buffer and set its data
	glBindVertexArray(cubeVAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

	// set the attribute and enable
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	unsigned int lightVAO;
	glGenVertexArrays(1, &lightVAO);
	glBindVertexArray(lightVAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// render loop
	while (!glfwWindowShouldClose(window))
	{
		// input
		processInput(window);
		// poll event
		glfwPollEvents();

		// draw a ImGUI frame
		ImGui_ImplOpenGL3_NewFrame();
		ImGui_ImplGlfw_NewFrame();
		ImGui::NewFrame();

		ImGui::Begin("Choose Task");
		ImGui::RadioButton("Phong Shading", &task, 0);
		ImGui::RadioButton("Gouraud Shading", &task, 1);
		ImGui::Checkbox("Bonus - Moving Light", &bonus);
		ImGui::SliderFloat("ambient", &ambient, 0.01f, 1.0f);
		ImGui::SliderFloat("diffuse", &diffuse, 0.01f, 1.0f);
		ImGui::SliderFloat("specular", &specular, 0.01f, 5.0f);
		ImGui::SliderFloat("shiny", &shiny, 10.0f, 50.0f);
		
		ImGui::End();

		// render
		glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		if (bonus) {
			lightPos = glm::vec3((float)sin(glfwGetTime()) * 2.0f, (float)cos(glfwGetTime()) * 2.0f, 0.0f);
		}
		unsigned int modelLoc, viewLoc, projLoc;
		if (task == 0) {
			glUseProgram(shader1);
			modelLoc = glGetUniformLocation(shader1, "model");
			viewLoc = glGetUniformLocation(shader1, "view");
			projLoc = glGetUniformLocation(shader1, "projection");
			
			glUniform3f(glGetUniformLocation(shader1, "lightColor"), 1.0f, 1.0f, 1.0f);
			glUniform3f(glGetUniformLocation(shader1, "objectColor"), 0.5f, 0.5f, 0.5f);
			glUniform3f(glGetUniformLocation(shader1, "lightPos"), lightPos.x, lightPos.y, lightPos.z);
			glUniform3f(glGetUniformLocation(shader1, "viewPos"), viewPos.x, viewPos.y, viewPos.z);
			glUniform1f(glGetUniformLocation(shader1, "ambient"), ambient);
			glUniform1f(glGetUniformLocation(shader1, "diffuse"), diffuse);
			glUniform1f(glGetUniformLocation(shader1, "specular"), specular);
			glUniform1f(glGetUniformLocation(shader1, "shiny"), shiny);
		}
		if (task == 1) {
			glUseProgram(shader2);
			modelLoc = glGetUniformLocation(shader2, "model");
			viewLoc = glGetUniformLocation(shader2, "view");
			projLoc = glGetUniformLocation(shader2, "projection");

			glUniform3f(glGetUniformLocation(shader2, "lightColor"), 1.0f, 1.0f, 1.0f);
			glUniform3f(glGetUniformLocation(shader2, "objectColor"), 0.5f, 0.5f, 0.5f);
			glUniform3f(glGetUniformLocation(shader2, "lightPos"), lightPos.x, lightPos.y, lightPos.z);
			glUniform3f(glGetUniformLocation(shader2, "viewPos"), viewPos.x, viewPos.y, viewPos.z);
			glUniform1f(glGetUniformLocation(shader2, "ambient"), ambient);
			glUniform1f(glGetUniformLocation(shader2, "diffuse"), diffuse);
			glUniform1f(glGetUniformLocation(shader2, "specular"), specular);
			glUniform1f(glGetUniformLocation(shader2, "shiny"), shiny);
		}

		// transform
		glm::mat4 model = glm::mat4(1.0f);
		glm::mat4 view = glm::mat4(1.0f);
		glm::mat4 projection = glm::mat4(1.0f);

		model = glm::scale(model, glm::vec3(0.3, 0.3, 0.3));
		model = glm::translate(model, glm::vec3(0.0, 0.0, 0.0));

		view = glm::lookAt(viewPos, glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));

		projection = glm::perspective(glm::radians(45.f), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.f);

		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

		// draw all the points
		glBindVertexArray(cubeVAO);
		glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

		// set light
		glUseProgram(LightShader);
		model = glm::mat4(1.0f);
		model = glm::translate(model, lightPos);
		model = glm::scale(model, glm::vec3(0.1f));
		glUniformMatrix4fv(glGetUniformLocation(LightShader, "model"), 1, GL_FALSE, glm::value_ptr(model));
		glUniformMatrix4fv(glGetUniformLocation(LightShader, "view"), 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(glGetUniformLocation(LightShader, "projection"), 1, GL_FALSE, glm::value_ptr(projection));

		// draw all the points
		glBindVertexArray(lightVAO);
		glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

		glBindVertexArray(0);
		ImGui::Render();
		ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

		// swap buffers
		glfwSwapBuffers(window);
	}

	// release resources
	ImGui_ImplOpenGL3_Shutdown();
	ImGui_ImplGlfw_Shutdown();
	ImGui::DestroyContext();
	glfwTerminate();
	return 0;
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// configure viewport with new size
	glViewport(0, 0, width, height);
}

void processInput(GLFWwindow *window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
}

int initPhongShader()
{
	// initialize suceess info
	int  success;
	char infoLog[512];

	// vertex shader code
	const char* vertexShaderSource = "#version 330 core\n"
		"layout(location = 0) in vec3 aPos;\n"
		"layout (location = 1) in vec3 aNormal;\n"
		"out vec3 FragPos;\n"
		"out vec3 Normal;\n"
		"uniform mat4 model;\n"
		"uniform mat4 view;\n"
		"uniform mat4 projection;\n"
		"void main()"
		"{"
		"	FragPos = vec3(model * vec4(aPos, 1.0));"
		"   Normal = mat3(transpose(inverse(model))) * aNormal;"
		"	gl_Position = projection * view * model * vec4(aPos, 1.0);"
		"}";
	// create & compile vertex shader
	unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);
	// check its success
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
	}


	// fragment shader code
	const char* fragmentShaderSource = "#version 330 core\n"
		"in vec3 Normal;\n"
		"in vec3 FragPos;\n"
		"out vec4 FragColor;"
		"uniform vec3 lightColor;\n"
		"uniform vec3 objectColor;\n"
		"uniform vec3 lightPos;\n"
		"uniform vec3 viewPos;\n"
		"uniform float ambient;\n"
		"uniform float diffuse;\n"
		"uniform float specular;\n"
		"uniform float shiny;\n"
		"void main()"
		"{"
		"	vec3 ambientI = ambient * lightColor;"

		"	vec3 norm = normalize(Normal);"
		"	vec3 lightDir = normalize(lightPos - FragPos);"
		"	float diff = max(dot(norm, lightDir), 0.0);"
		"	vec3 diffuseI = diffuse * diff * lightColor;"

		"	vec3 viewDir = normalize(viewPos - FragPos);"
		"	vec3 reflectDir = reflect(-lightDir, norm);"
		"	float spec = pow(max(dot(viewDir, reflectDir), 0.0), shiny);"
		"	vec3 specularI = specular * spec * lightColor;"

		"   vec3 result  = (ambientI + diffuseI + specularI) * objectColor;"
		"   FragColor = vec4(result, 1.0);"
		"}";
	// create & compile fragment shader
	unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);
	// check its success
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
	}

	// create shader program & attach shaders to it
	int shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	// link the shader program
	glLinkProgram(shaderProgram);
	glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
	}
	// delete shaader
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	return shaderProgram;
}

int initGouraudShader()
{
	// initialize suceess info
	int  success;
	char infoLog[512];

	// vertex shader code
	const char* vertexShaderSource = "#version 330 core\n"
		"layout(location = 0) in vec3 aPos;\n"
		"layout (location = 1) in vec3 aNormal;\n"
		"out vec3 result;\n"
		"uniform mat4 model;\n"
		"uniform mat4 view;\n"
		"uniform mat4 projection;\n"

		"uniform vec3 lightColor;\n"
		"uniform vec3 lightPos;\n"
		"uniform vec3 viewPos;\n"
		"uniform float ambient;\n"
		"uniform float diffuse;\n"
		"uniform float specular;\n"
		"uniform float shiny;\n"
		"void main()"
		"{"
		"	gl_Position = projection * view * model * vec4(aPos, 1.0);"

		"	vec3 FragPos = vec3(model * vec4(aPos, 1.0));"
		"   vec3 Normal = mat3(transpose(inverse(model))) * aNormal;"

		"	vec3 ambientI = ambient * lightColor;"

		"	vec3 norm = normalize(Normal);"
		"	vec3 lightDir = normalize(lightPos - FragPos);"
		"	float diff = max(dot(norm, lightDir), 0.0);"
		"	vec3 diffuseI = diffuse * diff * lightColor;"

		"	vec3 viewDir = normalize(viewPos - FragPos);"
		"	vec3 reflectDir = reflect(-lightDir, norm);"
		"	float spec = pow(max(dot(viewDir, reflectDir), 0.0), shiny);"
		"	vec3 specularI = specular * spec * lightColor;"

		"   result  = ambientI + diffuseI + specularI;"

		"}";
	// create & compile vertex shader
	unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);
	// check its success
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
	}


	// fragment shader code
	const char* fragmentShaderSource = "#version 330 core\n"
		"in vec3 result;\n"
		"out vec4 FragColor;"

		"uniform vec3 objectColor;\n"
		"void main()"
		"{"
		"   FragColor = vec4(result * objectColor, 1.0);"
		"}";
	// create & compile fragment shader
	unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);
	// check its success
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
	}

	// create shader program & attach shaders to it
	int shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	// link the shader program
	glLinkProgram(shaderProgram);
	glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
	}
	// delete shaader
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	return shaderProgram;
}

int initLightShader() {
	// initialize suceess info
	int  success;
	char infoLog[512];

	// vertex shader code
	const char* vertexShaderSource = "#version 330 core\n"
		"layout(location = 0) in vec3 aPos;\n"
		"out vec3 vertexColor;\n"
		"uniform mat4 model;\n"
		"uniform mat4 view;\n"
		"uniform mat4 projection;\n"
		"void main()"
		"{"
		"	gl_Position = projection * view * model * vec4(aPos, 1.0);"
		"}";
	// create & compile vertex shader
	unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);
	// check its success
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
	}


	// fragment shader code
	const char* fragmentShaderSource = "#version 330 core\n"
		"out vec4 FragColor;"
		"void main()"
		"{"
		"	FragColor = vec4(1.0f);"
		"}";
	// create & compile fragment shader
	unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);
	// check its success
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
	}

	// create shader program & attach shaders to it
	int shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	// link the shader program
	glLinkProgram(shaderProgram);
	glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
	}
	// delete shaader
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	return shaderProgram;
}