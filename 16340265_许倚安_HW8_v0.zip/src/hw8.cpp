#include <glad/glad.h> 
#include <GLFW/glfw3.h>
#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include <iostream>
#include <vector>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// to enable resizing the window
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
// to process the input in the window
void processInput(GLFWwindow *window);
void mouse_position_callback(GLFWwindow *window, double x, double y);
void mouse_click_callback(GLFWwindow *window, int button, int action, int mods);

// to draw a curve
void drawCurve(int n, bool bonus);
void drawLine(float x1, float y1, float x2, float y2);
void drawPoint(float x, float y, float z);

// to initialize shader
int initShader();

// settings
const unsigned int WINDOW_WIDTH = 800;
const unsigned int WINDOW_HEIGHT = 600;

// mouse pos
float mouseX, mouseY;
std::vector<glm::vec3> points;
float minDis = 0.1;
bool holding = false;
std::vector<glm::vec3>::iterator movingP;
float flag = 0.0f;

int main()
{
	// initialize a window
	glfwInit();
	// init the window with OpenGL 3.3 and with core mode
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// create a window with a size of w800 * h600 and a name
	GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, "Homework 8", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	// make the window a context
	glfwMakeContextCurrent(window);

	// initialize GLAD to use OpenGL functions before using any of them
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_position_callback);
	glfwSetMouseButtonCallback(window, mouse_click_callback);

	// initialize ImGUI
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO(); (void)io;
	ImGui::StyleColorsDark();
	ImGui_ImplGlfw_InitForOpenGL(window, true);
	ImGui_ImplOpenGL3_Init("#version 130");

	// to choose a task & get the parameters
	int task = 3;
	bool bonus = false;

	// init shader program
	int shaderProgram = initShader();

	// render loop
	while (!glfwWindowShouldClose(window))
	{

		// input
		processInput(window);
		// poll event
		glfwPollEvents();

		// draw a ImGUI frame
		ImGui_ImplOpenGL3_NewFrame();
		ImGui_ImplGlfw_NewFrame();
		ImGui::NewFrame();
		ImGui::Begin("Choose Task");
		ImGui::InputInt("n�ױ���������", &task, 1, 3);
		ImGui::Checkbox("Bonus", &bonus);
		ImGui::End();

		// render
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);
		
		glUseProgram(shaderProgram);
		
		for (auto p = points.begin(); p != points.end(); p++)
		{
			drawPoint(p->x, p->y, 0);
		}

		if (points.size() > 1)
		{
			auto lp = points.begin();
			auto p = points.begin();
			p++;
			for (p; p != points.end(); p++)
			{
				drawLine(lp->x, lp->y, p->x, p->y);
				lp = p;
			}
		}
		if (points.size() > task)
		{
			drawCurve(task, bonus);
		}

		ImGui::Render();
		ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

		// swap buffers
		glfwSwapBuffers(window);
	}

	// release resources
	ImGui_ImplOpenGL3_Shutdown();
	ImGui_ImplGlfw_Shutdown();
	ImGui::DestroyContext();
	glfwTerminate();
	return 0;
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// configure viewport with new size
	glViewport(0, 0, width, height);
}

void processInput(GLFWwindow *window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
}

void mouse_position_callback(GLFWwindow *window, double x, double y)
{
	mouseX = x / (WINDOW_WIDTH / 2) - 1.0f;
	mouseY = 1.0f - y / (WINDOW_HEIGHT / 2);
	if (holding == true)
	{
		movingP->x = mouseX;
		movingP->y = mouseY;
	}
}

void mouse_click_callback(GLFWwindow *window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
	{
		for (auto p = points.begin(); p != points.end(); p++)
		{
			if (glm::distance(*p, glm::vec3(mouseX, mouseY, 0)) < minDis)
			{
				p->x = mouseX;
				p->y = mouseY;
				holding = true;
				movingP = p;
				return;
			}
		}
		points.push_back(glm::vec3(mouseX, mouseY, 0));
	}
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE)
	{
		holding = false;
	}
	if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS)
	{
		if (points.size() > 0)
		{
			points.pop_back();
		}
	}
}

void drawPoint(float x, float y, float z)
{
	float vertices[] = {
		x, y, z
	};

	// generate buffer & array
	unsigned int VBO, VAO;
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);

	// bind the array, bind buffer and set its data
	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	// set the attribute and enable
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// draw all the points
	glDrawArrays(GL_POINTS, 0, 1);
	glBindVertexArray(0);
}

void drawLine(float x1, float y1, float x2, float y2)
{
	float vertices[] = {
		x1, y1, 0.f, x2, y2, 0.f
	};

	// generate buffer & array
	unsigned int VBO, VAO;
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);

	// bind the array, bind buffer and set its data
	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	// set the attribute and enable
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// draw all the points
	glDrawArrays(GL_LINES, 0, 2);
	glBindVertexArray(0);
}

int initShader()
{
	// initialize suceess info
	int  success;
	char infoLog[512];

	// vertex shader code
	const char* vertexShaderSource = "#version 330 core\n"
		"layout(location = 0) in vec3 aPos;\n"
		"void main()"
		"{"
		"	gl_Position = vec4(aPos, 1.0);"
		"}";
	// create & compile vertex shader
	unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);
	// check its success
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
	}


	// fragment shader code
	const char* fragmentShaderSource = "#version 330 core\n"
		"out vec4 FragColor;"
		"void main()"
		"{"
		"	FragColor = vec4(1.0f, 0.0f, 0.0f, 1.0f);"
		"}";
	// create & compile fragment shader
	unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);
	// check its success
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
	}

	// create shader program & attach shaders to it
	int shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	// link the shader program
	glLinkProgram(shaderProgram);
	glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
	}
	// delete shaader
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	return shaderProgram;
}

void drawCurve(int n, bool bonus)
{
	auto p = points.begin();
	auto p0 = points.begin();
	auto p1 = points.begin();
	auto p2 = points.begin();
	switch (n)
	{
	case 1:
		p += 1;
		for (p; p != points.end(); p++)
		{
			for (float t = 0; t <= 1; t += 0.01)
			{
				drawPoint((1-t)*p0->x + t*p->x, (1-t)*p0->y + t*p->y, 0);
			}
			p0 = p;
		}
		break;
	case 2:
		p += 2;
		p1 += 1;
		for (p; p != points.end(); p++)
		{
			for (float t = 0; t <= 1; t += 0.01)
			{
				flag = flag < 0.9f ? sin(glfwGetTime()) : flag;
				flag = sin(glfwGetTime()) < -0.9f ? sin(glfwGetTime()) : flag;
				if (!bonus || (bonus && t < flag))
				{
					float x = (1 - t)*(1 - t)*p0->x + 2 * t*(1 - t)*p1->x + t * t*p->x;
					float y = (1 - t)*(1 - t)*p0->y + 2 * t*(1 - t)*p1->y + t * t*p->y;
					drawPoint(x, y, 0.0f);
				}
			}
			p0 = p1;
			p1 = p;
		}
		break;
	case(3):
		p += 3;
		p2 += 2;
		p1 += 1;
		for (p; p != points.end(); p++)
		{
			for (float t = 0; t <= 1; t += 0.01)
			{
				flag = flag < 0.9f ? sin(glfwGetTime()) : flag;
				flag = sin(glfwGetTime()) < -0.9f ? sin(glfwGetTime()) : flag;
				if (!bonus || (bonus && t < flag))
				{
					float t0 = 1 - t;
					float b0 = t0 * t0 * t0;
					float b1 = 3 * t * t0 * t0;
					float b2 = 3 * t * t * t0;
					float b3 = t * t * t;
					float x = b0 * p0->x + b1 * p1->x + b2 * p2->x + b3 * p->x;
					float y = b0 * p0->y + b1 * p1->y + b2 * p2->y + b3 * p->y;
					drawPoint(x, y, 0.0f);
				}
			}
			p0 = p1;
			p1 = p2;
			p2 = p;
		}
		break;

	}
}